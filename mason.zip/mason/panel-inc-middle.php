<?php echo '</head>
<body id="page-top">
  <div id="wrapper">'; ?>
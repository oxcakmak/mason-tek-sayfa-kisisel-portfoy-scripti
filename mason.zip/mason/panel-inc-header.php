<?php
require_once("config.php");
echo '<!DOCTYPE html><html><head><meta charset="utf-8"><meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link href="'.PANEL_ASSETS_FOLDER.'vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
<link href="'.PANEL_ASSETS_FOLDER.'vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="'.PANEL_ASSETS_FOLDER.'css/ruang-admin.min.css" rel="stylesheet">
<link href="'.PANEL_ASSETS_FOLDER.'vendor/notyf/notyf.min.css" rel="stylesheet" type="text/css">
';
?>